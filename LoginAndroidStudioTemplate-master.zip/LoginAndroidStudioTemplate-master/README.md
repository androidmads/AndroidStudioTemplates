# LoginAndroidStudioTemplate


What you get?
-------------

This template generates code snippets for Login with Presenter, View, Model and Activity classes. Following are the different styles of login fields that are generated from this template.
  

Solid Simple Style|Solid Icon Style|Stroke Simple Style|Stroke Icon Style        
|-------------------------------|-----------------------------|-------------------------------|-----------------------------|
|<a href="https://imgur.com/5aovyaF"><img src="https://i.imgur.com/5aovyaF.png" title="source: imgur.com" height="403" width="200"/></a>|<a href="https://imgur.com/20VXcZv"><img src="https://i.imgur.com/20VXcZv.png" title="source: imgur.com" height="403" width="200" /></a>|<a href="https://imgur.com/W8sIrfU"><img src="https://i.imgur.com/W8sIrfU.png" title="source: imgur.com" height="403" width="200"/></a>|<a href="https://imgur.com/6jBdMHo"><img src="https://i.imgur.com/6jBdMHo.png" title="source: imgur.com" height="403" width="200"/></a>



Underline Simple Style|Underline Icon Style|TextInput Style      
|-------------------------------|-----------------------------|-------------------------------|
|<a href="https://imgur.com/znhiy2B"><img src="https://i.imgur.com/znhiy2B.png" title="source: imgur.com" height="403" width="200" /></a>|<a href="httpTs://imgur.com/DVqHIEQ"><img src="https://i.imgur.com/DVqHIEQ.png" title="source: imgur.com" height="403" width="200"/></a>|<a href="https://imgur.com/JY4kxZJ"><img src="https://i.imgur.com/JY4kxZJ.png" title="source: imgur.com" height="403" width="200" /></a>



Implementation
--------------

1. Download or clone this repo

<a href="https://imgur.com/e42Aypl"><img src="https://i.imgur.com/e42Aypl.png" title="source: imgur.com" /></a>

2. Rename the downloaded folder to LoginTemplates and copy the complete folder.

<a href="https://imgur.com/6x1L7Rg"><img src="https://i.imgur.com/6x1L7Rg.png" title="source: imgur.com" /></a>

Paste the selected files into

**For Mac**

Go to Applications, Choose Android Studio, Right click and select **Show Package Contents** options.

<a href="http://imgur.com/6jkayYm"><img src="http://i.imgur.com/6jkayYm.png" title="source: imgur.com" height="153" width="400"/></a>

> Navigate to > Contents - Plugins - android - lib - templates - other - paste the downloaded LoginTemplates folder

**For Windows**

Go to C - Program Files - Android - Android Studio

```
C:\Program Files\Android\Android Studio\
```

> Navigate to Plugins - android - lib - templates - other - paste the downloaded LoginTemplates folder

Usages
------

It is easy and pretty straight forward

> - Open your project in Android Studio.
> - Right click on your project root package.
> - Navigate to New - Other - LoginTemplates

<a href="https://imgur.com/UHKtQZP"><img src="https://i.imgur.com/UHKtQZP.png" title="source: imgur.com" /></a>

And This is how Template Wizard looks like!

<a href="https://imgur.com/IDMZVJ1"><img src="https://i.imgur.com/IDMZVJ1.png" title="source: imgur.com" /></a>
